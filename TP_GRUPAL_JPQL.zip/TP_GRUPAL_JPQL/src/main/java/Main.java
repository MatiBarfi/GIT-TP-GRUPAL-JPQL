import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();
            Date ahora = new Date();

            // 1. USUARIO Y PUNTO DE VENTA
            Usuario usuarioAdmin = Usuario.builder()
                    .usuario("admin")
                    .clave("123456")
                    .nombre("Juan")
                    .apellido("Perez")
                    .build();
            em.persist(usuarioAdmin);

            PuntoVenta puntoVenta = PuntoVenta.builder()
                    .numero(1)
                    .descripcion("Punto de Venta Centro")
                    .tipoEmision("Factura Electrónica")
                    .domicilioComercial("Av. San Martín 1000")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(puntoVenta);

            // 2. RUBRO
            Rubro rubroElec = new Rubro();
            rubroElec.setCodigo(10);
            rubroElec.setDenominacion("Electrónica");
            rubroElec.setFechaAlta(ahora);
            rubroElec.setFechaModificacion(ahora);
            rubroElec.setUsuarioCarga(usuarioAdmin);
            rubroElec.setUsuarioModificacion(usuarioAdmin);
            em.persist(rubroElec);

            // 3. CLIENTE (Contacto, Domicilio, Cliente)
            Contacto contacto = new Contacto();
            contacto.setEmail("juanperez@mail.com");
            em.persist(contacto);

            Domicilio domicilio = Domicilio.builder()
                    .nombreCalle("Belgrano")
                    .numeroCalle("456")
                    .build();
            em.persist(domicilio);

            Cliente cliente = Cliente.builder()
                    .cuitCuil("20-28123456-7")
                    .denominacion("Juan Perez")
                    .contacto(contacto)
                    .domicilio(domicilio)
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(cliente);

            // 4. MARCAS Y ARTÍCULOS
            Marca marcaLogi = Marca.builder()
                    .codigo(101)
                    .denominacion("Logitech")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(marcaLogi);

            Marca marcaSam = Marca.builder()
                    .codigo(102)
                    .denominacion("Samsung")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(marcaSam);

            Articulo artMouse = Articulo.builder()
                    .codigo("ART-001")
                    .denominacion("Mouse Inalámbrico")
                    .marca(marcaLogi)
                    .rubro(rubroElec) // Asignamos el rubro
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(artMouse);

            Articulo artMonitor = Articulo.builder()
                    .codigo("ART-002")
                    .denominacion("Monitor 24 Pulgadas")
                    .marca(marcaSam)
                    .rubro(rubroElec)
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(artMonitor); // Este artículo NO se facturará

            // 5. LISTAS DE PRECIO
            ListaPrecio listaPrecio = ListaPrecio.builder()
                    .codigo("LP-MAY")
                    .denominacion("Lista Mayorista")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(listaPrecio);

            ListaPrecioArticulo precioMouse = ListaPrecioArticulo.builder()
                    .listaPrecio(listaPrecio)
                    .articulo(artMouse)
                    .precioVenta(15000.0)
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(precioMouse);

            ListaPrecioArticulo precioMonitor = ListaPrecioArticulo.builder()
                    .listaPrecio(listaPrecio)
                    .articulo(artMonitor)
                    .precioVenta(150000.0)
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .build();
            em.persist(precioMonitor);

            // 6. FACTURAS Y DETALLES
            // Factura 1: $30,000 (Medio Valor)
            FacturaVenta factura1 = FacturaVenta.builder()
                    .numero(1001L)
                    .fechaEmision(ahora)
                    .puntoVenta(puntoVenta)
                    .importeCobrado(30000.0)
                    .importeSaldo(0.0)
                    .importeTotal(30000.0)
                    .cae("73428917238912")
                    .resultadoAfip("A")
                    .estado("Emitida")
                    .observaciones("Venta minorista")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .detalles(new ArrayList<>())
                    .build();

            FacturaVentaDetalle det1F1 = FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(precioMouse)
                    .descripcion("Mouse Inalámbrico - Unidad 1")
                    .cantidad(1.0)
                    .precioUnitario(15000.0)
                    .importeSubtotal(15000.0)
                    .factura(factura1)
                    .build();

            FacturaVentaDetalle det2F1 = FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(precioMouse)
                    .descripcion("Mouse Inalámbrico - Unidad 2")
                    .cantidad(1.0)
                    .precioUnitario(15000.0)
                    .importeSubtotal(15000.0)
                    .factura(factura1)
                    .build();

            factura1.getDetalles().add(det1F1);
            factura1.getDetalles().add(det2F1);
            em.persist(factura1);

            // Factura 2
            FacturaVenta factura2 = FacturaVenta.builder()
                    .numero(1002L)
                    .fechaEmision(ahora)
                    .puntoVenta(puntoVenta)
                    .importeCobrado(90000.0)
                    .importeSaldo(0.0)
                    .importeTotal(90000.0)
                    .cae("99887766554433")
                    .resultadoAfip("A")
                    .estado("Emitida")
                    .observaciones("Venta mayorista")
                    .fechaAlta(ahora)
                    .fechaModificacion(ahora)
                    .usuarioCarga(usuarioAdmin)
                    .usuarioModificacion(usuarioAdmin)
                    .detalles(new ArrayList<>())
                    .build();

            FacturaVentaDetalle det1F2 = FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(precioMouse)
                    .descripcion("Mouse Inalámbrico - Lote Mayorista")
                    .cantidad(6.0)
                    .precioUnitario(15000.0)
                    .importeSubtotal(90000.0)
                    .factura(factura2)
                    .build();

            factura2.getDetalles().add(det1F2);
            em.persist(factura2);

            em.getTransaction().commit();

            System.out.println("\n========================================");
            System.out.println("   DATOS DE PRUEBA GUARDADOS CON ÉXITO  ");
            System.out.println("========================================\n");

            // --- EJECUCIÓN E IMPRESIÓN DE CONSULTAS JPQL ---

            System.out.println("--- Consulta 1: Todas las facturas ---");
            List<FacturaVenta> todasLasFacturas = obtenerTodasLasFacturas(em);
            todasLasFacturas.forEach(f -> System.out.println("Factura Nro: " + f.getNumero() + " - Total: $" + f.getImporteTotal()));

            System.out.println("\n--- Consulta 2: Resumen Facturas (Proyección) ---");
            List<Object[]> resumenFacturas = obtenerResumenFacturas(em);
            resumenFacturas.forEach(fila -> System.out.println(Arrays.toString(fila)));

            System.out.println("\n--- Consulta 3: Artículos por Rubro ---");
            List<Articulo> articulosRubro = obtenerArticulosPorRubro(em, "Electrónica");
            System.out.println("Encontrados: " + articulosRubro.size());

            System.out.println("\n--- Consulta 4: Facturas por Rango de Fechas ---");
            List<FacturaVenta> facturasRango = obtenerFacturasPorRangoFechas(em, new Date(ahora.getTime() - 86400000), new Date(ahora.getTime() + 86400000));
            facturasRango.forEach(f -> System.out.println("Factura Nro: " + f.getNumero() + " - Fecha: " + f.getFechaEmision()));

            System.out.println("\n--- Consulta 5: Facturas Filtradas (Estado y Monto) ---");
            List<FacturaVenta> facturasFiltradas = obtenerFacturasFiltradas(em, "Emitida", 10000.0);
            facturasFiltradas.forEach(f -> System.out.println("Factura Nro: " + f.getNumero() + " - Estado: " + f.getEstado()));

            System.out.println("\n--- Consulta 6: Buscar Clientes (LIKE) ---");
            List<Cliente> clientesBuscados = buscarClientes(em, "Perez", "20-%");
            System.out.println("Clientes encontrados: " + clientesBuscados.size());

            System.out.println("\n--- Consulta 7: Estados de Factura (DISTINCT) ---");
            List<String> estadosFactura = obtenerEstadosFactura(em);
            estadosFactura.forEach(e -> System.out.println("Estado: " + e));

            System.out.println("\n--- Consulta 8: Estadísticas de Facturas (COUNT, SUM, AVG) ---");
            Object[] estadisticas = obtenerEstadisticasFacturas(em);
            System.out.println("Cantidad: " + estadisticas[0] + " | Suma: $" + estadisticas[1] + " | Promedio: $" + estadisticas[2]);

            System.out.println("\n--- Consulta 9: Puntos de Venta (IN) ---");
            List<PuntoVenta> puntosVentaIn = obtenerPuntosVentaPorNumeros(em, Arrays.asList(1, 2, 5));
            puntosVentaIn.forEach(pv -> System.out.println("PV Nro: " + pv.getNumero() + " - " + pv.getDescripcion()));

            System.out.println("\n--- Consulta 10: Facturas por Usuario (Navegación) ---");
            List<FacturaVenta> facturasUsuario = obtenerFacturasPorUsuarioCarga(em, "admin");
            facturasUsuario.forEach(f -> System.out.println("Factura Nro: " + f.getNumero() + " cargada por: " + f.getUsuarioCarga().getUsuario()));

            System.out.println("\n--- Consulta 11: Detalles por Punto de Venta (JOIN) ---");
            List<FacturaVentaDetalle> detallesPuntoVenta = obtenerDetallesPorPuntoVenta(em, 1);
            detallesPuntoVenta.forEach(d -> System.out.println("Detalle: " + d.getDescripcion() + " - Subtotal: $" + d.getImporteSubtotal()));

            System.out.println("\n--- Consulta 12: Artículos con Marca (LEFT JOIN) ---");
            List<Object[]> articulosMarca = obtenerArticulosConMarca(em);
            articulosMarca.forEach(fila -> System.out.println("Artículo: " + fila[0] + " | Marca: " + fila[1]));

            System.out.println("\n--- Consulta 13: Facturas por Marca (Navegación Múltiple) ---");
            List<FacturaVenta> facturasMarca = obtenerFacturasPorMarca(em, "Logitech");
            facturasMarca.forEach(f -> System.out.println("Factura Nro: " + f.getNumero() + " contiene artículos Logitech"));

            System.out.println("\n--- Consulta 14: Facturas sobre Promedio (Subconsulta) ---");
            List<FacturaVenta> facturasSobrePromedio = obtenerFacturasSobrePromedio(em);
            System.out.println("Facturas por encima del promedio: " + facturasSobrePromedio.size());
            facturasSobrePromedio.forEach(f -> System.out.println("Factura Nro: " + f.getNumero() + " | Monto: $" + f.getImporteTotal()));

            System.out.println("\n--- Consulta 15: Totales por Punto de Venta (GROUP BY) ---");
            List<Object[]> totalesPuntoVenta = obtenerTotalesPorPuntoVenta(em);
            totalesPuntoVenta.forEach(fila -> System.out.println("PV: " + fila[0] + " | Cantidad facturas: " + fila[1] + " | Total: $" + fila[2]));

            System.out.println("\n--- Consulta 16: Usuarios con múltiples facturas (HAVING) ---");
            List<String> usuariosMultiplesFacturas = obtenerUsuariosConMultiplesFacturas(em, 0L);
            usuariosMultiplesFacturas.forEach(u -> System.out.println("Usuario: " + u));

            System.out.println("\n--- Consulta 17: Totales por Marca (GROUP BY múltiple) ---");
            List<Object[]> totalesMarca = obtenerTotalesPorMarca(em);
            totalesMarca.forEach(fila -> System.out.println("Marca: " + fila[0] + " | Unidades vendidas: " + fila[1] + " | Recaudación: $" + fila[2]));

            System.out.println("\n--- Consulta 18: Marcas con Artículos Facturados (EXISTS) ---");
            List<Marca> marcasFacturadas = obtenerMarcasConArticulosFacturados(em);
            marcasFacturadas.forEach(m -> System.out.println("Marca facturada: " + m.getDenominacion()));

            System.out.println("\n--- Consulta 19: Artículos No Facturados (NOT EXISTS) ---");
            List<Articulo> articulosNoFacturados = obtenerArticulosNoFacturados(em);
            System.out.println("Artículos sin facturar: " + articulosNoFacturados.size());
            articulosNoFacturados.forEach(a -> System.out.println("Artículo huérfano: " + a.getDenominacion()));

            System.out.println("\n--- Consulta 20: Clasificación Facturas (CASE WHEN) ---");
            List<Object[]> clasificacionFacturas = obtenerClasificacionFacturas(em);
            clasificacionFacturas.forEach(fila -> System.out.println("Factura Nro: " + fila[0] + " | Monto: $" + fila[1] + " | Categoría: " + fila[2]));

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    // =====================================================================
    //                        MÉTODOS DE CONSULTAS
    // =====================================================================

    public static List<FacturaVenta> obtenerTodasLasFacturas(EntityManager em) {
        String jpql = "SELECT f FROM FacturaVenta f";
        return em.createQuery(jpql, FacturaVenta.class).getResultList();
    }

    public static List<Object[]> obtenerResumenFacturas(EntityManager em) {
        String jpql = "SELECT f.numero, f.fechaEmision, f.importeTotal FROM FacturaVenta f";
        return em.createQuery(jpql, Object[].class).getResultList();
    }

    public static List<Articulo> obtenerArticulosPorRubro(EntityManager em, String denominacionRubro) {
        String jpql = "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :denominacion";
        return em.createQuery(jpql, Articulo.class)
                .setParameter("denominacion", denominacionRubro)
                .getResultList();
    }

    public static List<FacturaVenta> obtenerFacturasPorRangoFechas(EntityManager em, Date desde, Date hasta) {
        String jpql = "SELECT f FROM FacturaVenta f " +
                "WHERE f.fechaEmision BETWEEN :desde AND :hasta " +
                "ORDER BY f.fechaEmision";
        return em.createQuery(jpql, FacturaVenta.class)
                .setParameter("desde", desde)
                .setParameter("hasta", hasta)
                .getResultList();
    }

    public static List<FacturaVenta> obtenerFacturasFiltradas(EntityManager em, String estado, Double importeMinimo) {
        String jpql = "SELECT f FROM FacturaVenta f WHERE f.estado = :estado AND f.importeTotal > :importeMinimo AND f.fechaAnulacion IS NULL";
        return em.createQuery(jpql, FacturaVenta.class)
                .setParameter("estado", estado)
                .setParameter("importeMinimo", importeMinimo)
                .getResultList();
    }

    public static List<Cliente> buscarClientes(EntityManager em, String textoParcial, String prefijoCuit) {
        String jpql = "SELECT c FROM Cliente c WHERE LOWER(c.denominacion) LIKE LOWER(CONCAT('%', :textoParcial, '%')) OR c.cuitCuil LIKE :prefijoCuit";
        return em.createQuery(jpql, Cliente.class)
                .setParameter("textoParcial", textoParcial)
                .setParameter("prefijoCuit", prefijoCuit)
                .getResultList();
    }

    public static List<String> obtenerEstadosFactura(EntityManager em) {
        String jpql = "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC";
        return em.createQuery(jpql, String.class).getResultList();
    }

    public static Object[] obtenerEstadisticasFacturas(EntityManager em) {
        String jpql = "SELECT COUNT(f), SUM(f.importeTotal), AVG(f.importeTotal) FROM FacturaVenta f";
        return em.createQuery(jpql, Object[].class).getSingleResult();
    }

    public static List<PuntoVenta> obtenerPuntosVentaPorNumeros(EntityManager em, List<Integer> numerosBuscados) {
        String jpql = "SELECT p FROM PuntoVenta p WHERE p.numero IN :listaNumeros";
        return em.createQuery(jpql, PuntoVenta.class)
                .setParameter("listaNumeros", numerosBuscados)
                .getResultList();
    }

    public static List<FacturaVenta> obtenerFacturasPorUsuarioCarga(EntityManager em, String nombreUsuario) {
        String jpql = "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :usuario";
        return em.createQuery(jpql, FacturaVenta.class)
                .setParameter("usuario", nombreUsuario)
                .getResultList();
    }

    public static List<FacturaVentaDetalle> obtenerDetallesPorPuntoVenta(EntityManager em, int numeroPuntoVenta) {
        String jpql = "SELECT d FROM FacturaVentaDetalle d " +
                "JOIN d.factura f " +
                "JOIN f.puntoVenta pv " +
                "WHERE pv.numero = :numeroPuntoVenta";
        return em.createQuery(jpql, FacturaVentaDetalle.class)
                .setParameter("numeroPuntoVenta", numeroPuntoVenta)
                .getResultList();
    }

    public static List<Object[]> obtenerArticulosConMarca(EntityManager em) {
        String jpql = "SELECT a.denominacion, m.denominacion " +
                "FROM Articulo a " +
                "LEFT JOIN a.marca m " +
                "ORDER BY a.denominacion";
        return em.createQuery(jpql, Object[].class).getResultList();
    }

    public static List<FacturaVenta> obtenerFacturasPorMarca(EntityManager em, String denominacionMarca) {
        String jpql = "SELECT DISTINCT f FROM FacturaVenta f " +
                "JOIN f.detalles d " +
                "WHERE d.listaPrecioArticulo.articulo.marca.denominacion = :marca";
        return em.createQuery(jpql, FacturaVenta.class)
                .setParameter("marca", denominacionMarca)
                .getResultList();
    }

    public static List<FacturaVenta> obtenerFacturasSobrePromedio(EntityManager em) {
        String jpql = "SELECT f FROM FacturaVenta f " +
                "WHERE f.importeTotal > (SELECT AVG(f2.importeTotal) FROM FacturaVenta f2)";
        return em.createQuery(jpql, FacturaVenta.class).getResultList();
    }

    public static List<Object[]> obtenerTotalesPorPuntoVenta(EntityManager em) {
        String jpql = "SELECT f.puntoVenta.descripcion, COUNT(f), SUM(f.importeTotal) FROM FacturaVenta f GROUP BY f.puntoVenta.descripcion";
        return em.createQuery(jpql, Object[].class).getResultList();
    }

    public static List<String> obtenerUsuariosConMultiplesFacturas(EntityManager em, Long cantidadMinima) {
        String jpql = "SELECT f.usuarioCarga.nombre FROM FacturaVenta f GROUP BY f.usuarioCarga.nombre HAVING COUNT(f) > :cantidadMinima";
        return em.createQuery(jpql, String.class)
                .setParameter("cantidadMinima", cantidadMinima)
                .getResultList();
    }

    public static List<Object[]> obtenerTotalesPorMarca(EntityManager em) {
        String jpql = "SELECT d.listaPrecioArticulo.articulo.marca.denominacion, SUM(d.cantidad), SUM(d.importeSubtotal) FROM FacturaVentaDetalle d GROUP BY d.listaPrecioArticulo.articulo.marca.denominacion";
        return em.createQuery(jpql, Object[].class).getResultList();
    }

    public static List<Marca> obtenerMarcasConArticulosFacturados(EntityManager em) {
        String jpql = "SELECT m FROM Marca m WHERE EXISTS (SELECT fvd FROM FacturaVentaDetalle fvd WHERE fvd.listaPrecioArticulo.articulo.marca = m)";
        return em.createQuery(jpql, Marca.class).getResultList();
    }

    public static List<Articulo> obtenerArticulosNoFacturados(EntityManager em) {
        String jpql = "SELECT a FROM Articulo a WHERE NOT EXISTS (SELECT fvd FROM FacturaVentaDetalle fvd WHERE fvd.listaPrecioArticulo.articulo = a)";
        return em.createQuery(jpql, Articulo.class).getResultList();
    }

    public static List<Object[]> obtenerClasificacionFacturas(EntityManager em) {
        String jpql = "SELECT f.numero, f.importeTotal, " +
                "CASE WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' " +
                "WHEN f.importeTotal BETWEEN 10000 AND 50000 THEN 'MEDIO VALOR' " +
                "ELSE 'BAJO VALOR' END " +
                "FROM FacturaVenta f ORDER BY f.importeTotal DESC";
        return em.createQuery(jpql, Object[].class).getResultList();
    }
}